<?php
include 'koneksi.php';

$id = $_GET['id'];
$query = "SELECT * FROM produk WHERE id_produk = $id";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

if (isset($_POST['update'])) {
    $nama  = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $stok  = $_POST['stok'];

    $query_update = "UPDATE produk SET nama_produk='$nama', harga='$harga', stok='$stok' WHERE id_produk=$id";
    if (mysqli_query($koneksi, $query_update)) {
        header("Location: index.php");
    } else {
        echo "<script>alert('Gagal memperbarui data');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Produk Sembako</title>
    
    <style>
        :root {
            --primary-color: #0d8a72;
            --secondary-color: #0b6e5b;
            --accent-color: #ffb703;
            --danger-color: #e63946;
            --bg-color: #f4f7f6;
            --text-color: #2b2d42;
        }
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: var(--bg-color); color: var(--text-color); margin: 0; padding: 20px; }
        .container { max-width: 1000px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        h1 { color: var(--primary-color); border-bottom: 3px solid var(--accent-color); padding-bottom: 10px; margin-top: 0; font-size: 24pt; display: flex; align-items: center; justify-content: space-between; }
        h2 { color: var(--secondary-color); margin-top: 0; }
        .badge-rpl { font-size: 12pt; background: var(--accent-color); color: #000; padding: 5px 15px; border-radius: 20px; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #e0e0e0; }
        th { background-color: var(--primary-color); color: white; font-weight: 600; }
        tr:hover { background-color: #f9fbfb; }
        .btn { display: inline-block; padding: 10px 20px; color: white; text-decoration: none; border-radius: 6px; font-weight: bold; border: none; cursor: pointer; transition: background 0.2s; font-size: 10pt; }
        .btn-primary { background-color: var(--primary-color); }
        .btn-primary:hover { background-color: var(--secondary-color); }
        .btn-accent { background-color: var(--accent-color); color: #333; }
        .btn-accent:hover { background-color: #e5a100; }
        .btn-danger { background-color: var(--danger-color); }
        .btn-danger:hover { background-color: #c92a3a; }
        .btn-sm { padding: 6px 12px; font-size: 9pt; border-radius: 4px; }
        .btn-group { margin-bottom: 20px; display: flex; gap: 10px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 6px; font-weight: 600; color: #4a4a4a; }
        input, select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 6px; font-size: 11pt; }
        input:focus, select:focus { border-color: var(--primary-color); outline: none; }
        .alert { background-color: #e1f5fe; color: #0288d1; padding: 12px; border-radius: 6px; margin-bottom: 20px; border-left: 5px solid #0288d1; font-weight: 500; }
        .total-box { background: #e8f5e9; border: 2px dashed var(--primary-color); padding: 15px; border-radius: 8px; font-size: 14pt; font-weight: bold; color: var(--secondary-color); margin: 15px 0; text-align: center; }
    </style>

</head>
<body>
    <div class="container" style="max-width: 600px;">
        <h1>✏️ Edit Data Sembako</h1>
        <form action="" method="POST" style="margin-top: 20px;">
            <div class="form-group">
                <label>Nama Produk / Sembako</label>
                <input type="text" name="nama_produk" value="<?= $data['nama_produk']; ?>" required>
            </div>
            <div class="form-group">
                <label>Harga (Rp)</label>
                <input type="number" name="harga" value="<?= $data['harga']; ?>" required>
            </div>
            <div class="form-group">
                <label>Stok Barang</label>
                <input type="number" name="stok" value="<?= $data['stok']; ?>" required>
            </div>
            <div style="margin-top: 25px; display: flex; gap: 10px;">
                <button type="submit" name="update" class="btn btn-primary" style="flex: 1;">🔄 Perbarui Data</button>
                <a href="index.php" class="btn btn-danger" style="text-align: center; width: 100px;">Batal</a>
            </div>
        </form>
    </div>
</body>
</html>