-- Database: toko_sembako_gemini
CREATE DATABASE IF NOT EXISTS toko_sembako_gemini;
USE toko_sembako_gemini;

-- 1. Tabel Produk Sembako
CREATE TABLE IF NOT EXISTS produk (
    id_produk INT AUTO_INCREMENT PRIMARY KEY,
    nama_produk VARCHAR(100) NOT NULL,
    harga INT NOT NULL,
    stok INT NOT NULL
);

-- 2. Tabel Transaksi
CREATE TABLE IF NOT EXISTS transaksi (
    id_transaksi INT AUTO_INCREMENT PRIMARY KEY,
    id_produk INT,
    jumlah_beli INT NOT NULL,
    total_harga INT NOT NULL,
    tanggal_transaksi TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_produk) REFERENCES produk(id_produk) ON DELETE CASCADE
);

-- 3. Data Awal (Sesuai Gambar Soal UKK)
INSERT INTO produk (nama_produk, harga, stok) VALUES
('Beras', 15000, 50),
('Telur', 26000, 100),
('Minyak Goreng', 18000, 30),
('Gula', 16000, 40),
('Mi Instan', 3500, 200)
ON DUPLICATE KEY UPDATE nama_produk=nama_produk;
