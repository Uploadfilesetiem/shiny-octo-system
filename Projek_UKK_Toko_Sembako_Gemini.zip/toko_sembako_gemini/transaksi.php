<?php
include 'koneksi.php';

// Ambil daftar produk untuk dropdown pilihan kasir
$query_produk = "SELECT * FROM produk WHERE stok > 0";
$result_produk = mysqli_query($koneksi, $query_produk);

// Logika ketika transaksi disubmit
if (isset($_POST['bayar'])) {
    $id_produk   = $_POST['id_produk'];
    $jumlah_beli = $_POST['jumlah_beli'];
    
    // Ambil harga produk pilihan
    $q_detail  = "SELECT harga, stok FROM produk WHERE id_produk = $id_produk";
    $res_detail = mysqli_query($koneksi, $q_detail);
    $prod      = mysqli_fetch_assoc($res_detail);
    
    if ($jumlah_beli > $prod['stok']) {
        echo "<script>alert('Stok tidak mencukupi!');</script>";
    } else {
        $total_harga = $prod['harga'] * $jumlah_beli;
        
        // Insert ke tabel transaksi
        $query_trans = "INSERT INTO transaksi (id_produk, jumlah_beli, total_harga) VALUES ($id_produk, $jumlah_beli, $total_harga)";
        
        // Kurangi stok produk
        $query_stok  = "UPDATE produk SET stok = stok - $jumlah_beli WHERE id_produk = $id_produk";
        
        if (mysqli_query($koneksi, $query_trans) && mysqli_query($koneksi, $query_stok)) {
            echo "<script>alert('Transaksi Berhasil! Total: Rp " . number_format($total_harga, 0, ',', '.') . "'); window.location='riwayat.php';</script>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kasir Toko Sembako Gemini</title>
    
    <style>
        :root {
            --primary-color: #0d8a72;
            --secondary-color: #0b6e5b;
            --accent-color: #ffb703;
            --danger-color: #e63946;
            --bg-color: #f4f7f6;
            --text-color: #2b2d42;
        }
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: var(--bg-color); color: var(--text-color); margin: 0; padding: 20px; }
        .container { max-width: 1000px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        h1 { color: var(--primary-color); border-bottom: 3px solid var(--accent-color); padding-bottom: 10px; margin-top: 0; font-size: 24pt; display: flex; align-items: center; justify-content: space-between; }
        h2 { color: var(--secondary-color); margin-top: 0; }
        .badge-rpl { font-size: 12pt; background: var(--accent-color); color: #000; padding: 5px 15px; border-radius: 20px; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #e0e0e0; }
        th { background-color: var(--primary-color); color: white; font-weight: 600; }
        tr:hover { background-color: #f9fbfb; }
        .btn { display: inline-block; padding: 10px 20px; color: white; text-decoration: none; border-radius: 6px; font-weight: bold; border: none; cursor: pointer; transition: background 0.2s; font-size: 10pt; }
        .btn-primary { background-color: var(--primary-color); }
        .btn-primary:hover { background-color: var(--secondary-color); }
        .btn-accent { background-color: var(--accent-color); color: #333; }
        .btn-accent:hover { background-color: #e5a100; }
        .btn-danger { background-color: var(--danger-color); }
        .btn-danger:hover { background-color: #c92a3a; }
        .btn-sm { padding: 6px 12px; font-size: 9pt; border-radius: 4px; }
        .btn-group { margin-bottom: 20px; display: flex; gap: 10px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 6px; font-weight: 600; color: #4a4a4a; }
        input, select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 6px; font-size: 11pt; }
        input:focus, select:focus { border-color: var(--primary-color); outline: none; }
        .alert { background-color: #e1f5fe; color: #0288d1; padding: 12px; border-radius: 6px; margin-bottom: 20px; border-left: 5px solid #0288d1; font-weight: 500; }
        .total-box { background: #e8f5e9; border: 2px dashed var(--primary-color); padding: 15px; border-radius: 8px; font-size: 14pt; font-weight: bold; color: var(--secondary-color); margin: 15px 0; text-align: center; }
    </style>

    <script>
        // FUNGSI LOGIKA TRANSAKSI OTOMATIS (POIN KRUSIAL GAMBAR UKK)
        function hitungOtomatis() {
            var selectProduk = document.getElementById('id_produk');
            var jumlahBeli   = document.getElementById('jumlah_beli').value;
            
            // Mengambil attribute data-harga dari option yang dipilih
            var harga = selectProduk.options[selectProduk.selectedIndex].getAttribute('data-harga');
            
            if (harga && jumlahBeli) {
                var total = harga * jumlahBeli;
                // Format rupiah tampilan teks dasar
                document.getElementById('total_tampilan').innerText = "Rp " + total.toLocaleString('id-ID');
            } else {
                document.getElementById('total_tampilan').innerText = "Rp 0";
            }
        }
    </script>
</head>
<body>
    <div class="container" style="max-width: 650px;">
        <h1>🛒 Menu Transaksi Kasir</h1>
        <div class="alert">⚠️ <b>Poin Krusial Soal:</b> Hitung otomatis jumlah beli (1x, 5x, dll) × Harga!</div>
        
        <form action="" method="POST">
            <div class="form-group">
                <label>Pilih Komoditas Sembako</label>
                <select name="id_produk" id="id_produk" onchange="hitungOtomatis()" required>
                    <option value="">-- Pilih Sembako --</option>
                    <?php 
                    mysqli_data_seek($result_produk, 0);
                    while($p = mysqli_fetch_assoc($result_produk)) { 
                        echo "<option value='".$p['id_produk']."' data-harga='".$p['harga']."'>".$p['nama_produk']." (Rp ".number_format($p['harga'],0,',','.')." | Stok: ".$p['stok'].")</option>";
                    } 
                    ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Jumlah Beli (Qty)</label>
                <input type="number" name="jumlah_beli" id="jumlah_beli" min="1" placeholder="Masukkan jumlah beli" oninput="hitungOtomatis()" required>
            </div>
            
            <div class="total-box">
                Total Belanja: <span id="total_tampilan">Rp 0</span>
            </div>
            
            <div style="margin-top: 25px; display: flex; gap: 10px;">
                <button type="submit" name="bayar" class="btn btn-accent" style="flex: 1; font-size: 12pt;">⚡ Proses & Cetak Transaksi</button>
                <a href="index.php" class="btn btn-danger" style="text-align: center; line-height: 25px; width: 100px;">Kembali</a>
            </div>
        </form>
    </div>
</body>
</html>