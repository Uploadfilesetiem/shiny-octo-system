<?php
include 'koneksi.php';
$id = $_GET['id'];

$query = "DELETE FROM produk WHERE id_produk = $id";
if (mysqli_query($koneksi, $query)) {
    header("Location: index.php");
} else {
    echo "<script>alert('Gagal menghapus data'); window.location='index.php';</script>";
}
?>